;;;; package.lisp — package definitions for DwightASpencerCom system
;;;;
;;;; The DwightASpencerCom package was first introduced on the homepage at
;;;; https://dwightaspencer.com — the finger/whoami block is the canonical
;;;; package definition. This file is the machine-readable extension of that
;;;; same program.

(in-package #:cl-user)

;;; ── Logic layer — micro-Prolog engine from ml-prolog-pokemon ─────────────────
;;; Architecture: github.com/denzuko/ml-prolog-pokemon/logic-engine.lisp
;;; Same prolog-db struct, same db-assert/db-prove-all interface.
;;; Posts become facts exactly as Pokémon moves became facts in the study.
(defpackage #:com.dwightaspencer/logic
  (:use #:cl)
  (:export
   ;; database
   #:make-post-kb
   #:db-assert
   #:db-prove-first
   #:db-provable-p
   #:db-prove-all
   #:db-var-all
   ;; internals (exposed for corpus layer)
   #:%var-p #:%walk #:%unify #:%subst #:%lookup #:db-clauses #:prolog-db
   ;; struct predicate
   #:prolog-db-p))

;;; ── Corpus layer — post/tag/author facts ─────────────────────────────────────
;;; Mirrors pokemon-catalog: assert-catalog-facts → assert-post-facts
;;; Fact schemas:
;;;   (post   slug title date word-count)
;;;   (tag    slug tag-name)
;;;   (author slug orcid)
(defpackage #:com.dwightaspencer/corpus
  (:use #:cl)
  (:local-nicknames (#:logic #:com.dwightaspencer/logic))
  (:export
   #:assert-post-facts
   #:find-post
   #:find-by-tag
   #:all-posts
   #:all-tags
   #:make-site-kb
   #:load-live-corpus
   #:+corpus-url+
   ;; search index
   #:+search-index+
   #:+dist-root+))

;;; ── Render layer — PostScript output ─────────────────────────────────────────
(defpackage #:com.dwightaspencer/render
  (:use #:cl)
  (:local-nicknames (#:corpus #:com.dwightaspencer/corpus))
  (:export
   #:render))

;;; ── Top-level DwightASpencerCom package ───────────────────────────────────────
;;; This is the package the finger block declares on the homepage.
;;; Loading this system extends it with corpus + render capabilities.
(defpackage #:DwightASpencerCom
  (:use #:cl #:com.dwightaspencer/logic #:com.dwightaspencer/corpus #:com.dwightaspencer/render)
  ;; Shadow corpus symbols re-exported as 1-arg wrappers using global *kb*
  (:shadow #:find-post #:find-by-tag #:all-posts)
  (:export
   ;; State
   #:*kb*
   #:*self*
   ;; From the homepage finger block — still works
   #:finger
   #:Self
   #:AboutMe
   ;; Knowledge base
   #:make-kb
   #:kb
   #:load-live-corpus
   ;; Corpus queries
   #:query
   #:find-post
   #:find-by-tag
   #:all-posts
   ;; Render
   #:render))

(defpackage #:com.dwightaspencer/rag
  (:use #:cl)
  (:local-nicknames (#:logic  #:com.dwightaspencer/logic)
                    (#:corpus #:com.dwightaspencer/corpus))
  (:export
   #:char-trigrams
   #:word-trigrams
   #:build-trigram-index
   #:trigram-similarity
   #:extract-tonal-rules
   #:tonal-match-p
   #:ast-category-match-p
   #:*category-compatibility*
   #:token-result
   #:token-result-token
   #:token-result-probability
   #:token-result-category
   #:token-result-tonal-pass
   #:token-result-ast-pass
   #:token-result-score
   #:score-candidate
   #:score-candidates
   #:select-token
   #:generate-response))
